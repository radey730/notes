[[Gap analysis]]
[[Zero Trust Security]]- 
	Policy Enforcement Point vs Policy Decision point
	
[[Honeypots]]
	which statements are true?
	Honeynet?
	honeytoken?
		What should not be used as honey tokens?
			Shared Service Accounts, critical application files/data, commonly accessed files or shared drives
			They should appear real enough but still isolated and unintrusive

BIA  A process used by organizations to assess and evaluate the potential impact of disruptive incidents or disasters on their critical business functions and operations is referred to as: 
	[[Business Impact Analysis]]

A hierarchical system for the creation, management, storage, distribution, and revocation of digital certificates is known as: 
	[[PKI]]

[[Asymmetric Encryption | Public- Private key]]
	Public: encrypts data, verifies digital signature
	Private: Decrypts data, signs digital signature

Key Escrow, Recovery Agent (RA)
	Mechanisms that ensures access to cryptographic keys in situations like data recovery or regulatory compliance
Key Escrow
	Store cryptographic keys with a trusted third party
Recovery Agent
	Designated Entity authorized to recover encrypted data, typically within organization

Questions
	Which of the following answers refers to a data storage device equipped with hardware-level encryption functionality?
		A: SED ; Self Encrypting Drive
	Which of the answers listed below refers to software technology designed to provide confidentiality for an entire data storage device?
		A: FDE Full Disk Encryption
	 Which of the following software application tools are specifically designed for implementing encryption algorithms to secure data communication and storage? (Select 2 answers)
	VPN-
	[[SSH]]-
	GPG- correct
	IPsec
	PGP
	What is the name of a network protocol that secures web traffic via SSL/TLS encryption?
	A: HTTPS

EFS:

11/25

Questions:
	Which of the answers listed below refers to a Zero Trust Control Plane security approach that takes into account user identity, device security, network conditions, and other contextual information to enable dynamic access decisions?
		Adaptive Identity
	What are the key components of the Zero Trust Control Plane's Policy Decision Point (PDP)? (Select 2 answers)
		Policy Engine PE and Policiy Admin PA
	A honeyfile can be any type of file (e.g., a document, email message, image, or video file) containing real user data intentionally placed within a network or system to attract potential attackers or unauthorized users.
		False
	What is a honeytoken?
		Unique identifier that TRACKS Attackers
	Key escrow is a cryptographic technique that enables storing copies of encryption keys with a trusted third party. A Recovery Agent (RA) is a trusted third party (an individual, entity, or system) who is authorized to assist in the retrieval of encryption keys and data on behalf of the data owner. Key escrow and RA are both used to ensure that encrypted data can be decrypted even if the data owner loses access to their encryption key. Since key escrow and RAs are both components of a single security solution, the only way to implement key escrow systems is with the use of RAs.
		 False
	An MS Windows component that enables encryption of individual files is called:
		 EFS
	Which of the following software application tools are specifically designed for implementing encryption algorithms to secure data communication and storage?
		GPG and PGP
	