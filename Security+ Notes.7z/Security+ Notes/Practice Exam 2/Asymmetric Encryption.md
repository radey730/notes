[[Encryption Algorithms |Read about Specific Encryption Methods here ]]
###### AKA public key encryption

- **Public Key**: Used to encrypt data and verify digital signatures.
- **Private Key**: Used to decrypt data and sign digital messages.

How It Works
	**Encryption/Decryption**:
	    - The public key is used by the sender to encrypt a message.
	    - The recipient uses the private key to decrypt the message.
	 **Digital Signatures**:
	    - The sender signs a message with their private key.
	    - The recipient verifies the signature using the sender’s public key.

#### Benefits:

- **Confidentiality**: Only the person with the private key can decrypt the message.
- **Authentication**: Verifies the sender's identity using digital signatures.
- **Integrity**: Ensures the message hasn’t been altered.
- **Non-repudiation**: Prevents the sender from denying they sent the message.




## Asymmetric Ciphers
* DHE
* ECC
* RSA