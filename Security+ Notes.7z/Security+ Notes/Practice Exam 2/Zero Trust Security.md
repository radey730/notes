"Never Trust, Always Verify"
Threats exist inside and outside the network so no user, device, or system can be automatically trusted. 
Every access request must be authenticated, authorized, and continuously validated. 

To implement zero trust, break security devices into smaller components
	Data Plane
		part of device performing actual security process.
		could be ***switch, router, or firewall*** that's processing ***frames packets and network data*** in real time
	Control Plane
		**Manages actions occurring in data plane**
		*Configuring policies* for devices to determine whether data may traverse the network
		Setting up forwarding policy
		**Adaptive Identity**
			dynamically adjusts access requirements based on 
				User identity
				Device security
				Network conditions
				context
		**Routing table**
			understanding how routing may be configured 
	

Key Principles of Zero Trust:
	Least Privilege Access
		WHAT: Users and systems only get the minimum access needed to perform their job 
		WHY: reduced the risk if the case of a compromised account.
	Micro segmentation 
		WHAT: Networks are divided into smaller zones and access between networks is restricted.
		WHY: If an attacker gains access to one part of the network, they cannot easily move laterally to other parts.
	Verify everything: 
		Every user, device, and request must be verified regardless of location. This involves authentication methods such as MFA.  
	Monitoring and Logging
		Security teams constantly monitor for suspicious activity.
		Logging and analyzing network traffic, user behaviors, and device actions. 	

PEP intercepts, PDP decides
	**PEP** Policy Enforcement Point: Intercepts access requests and checks for policy requirements before granting access 
		DATA PLANE
		Enforces security policies by allowing or denying access requests to resources
		 Example: VPN gateway, Firewall, proxy server
	**PDP** Policy Decision Point: Makes decision to grant access or not to a request
		When PEP intercepts an access request, it queries PDP to get an authorization decision
		**PE** Policy Engine
			performs decision making
				After making a decision, PE passes result to PA
	**PA** Policy Admin: coordinates between PEP and PDP
		delivery of access tokens or credentials for enforcement by PEP

Data plane vs Control plane example
		We have a physical switch and we want to be able to break out the different planes of operation.
			At the Bottom of the switch are all of different interfaces that are used to move data from one part of the network to another.
				All of the traffic we're forwarding in on the data plane.
				But the device needs configuration 
					there needs to be network address settings
						would take place in control plane