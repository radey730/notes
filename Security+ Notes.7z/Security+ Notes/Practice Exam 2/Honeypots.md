security mechanism designed to lure and trap attackers by stimulating a vulnerable system or network.
	Its purpose is to detect, deflect, or study hacking attempts.
	Can gather info about attack methods, malware, and attacker behavior without actually compromising a real network

Key Features of a honeypot
	Decoy System- it appears real.
		Fake server, database, or network with apparent vulnerabilities 
	Isolated environment- its placed in a controlled and monitored environment separate from the actual network
		Allows for attacks to be observed without causing any harm
	Intelligence gathering- honeypots detect data on the types of attacks, tools and tactics used by attackers

Honeynet - Network of honeypots
	Purpose: to study large scale coordinated attacks
	Example: 
		could simulate a corporate network, with fake servers, databases, and workstations
Honeytoken - piece of data planted to detect unauthorized access 
	Example: fake admin password stored in database
		If someone tries to use it, the security team knows there's an unauthorized activity 
Honeyfile
	 **specific type of honeytoken** designed to look like a sensitive document or file.
