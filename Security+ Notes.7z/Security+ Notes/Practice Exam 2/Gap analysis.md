Process used to identify the difference or "gap" between an organizations currents security practices and its desired or required security state. 
helps pinpoint the areas that need improvement to meet security standards

Process:
	1. Assess current state of security measures policies and practices 
	2. Identify desired state (I.E compliance with HIPAA, PCI-DSS)
	3. analyze gap- compare the two states and find what's insufficient 
	4. create action plan that implements new controls policies and technologies

#vocab 