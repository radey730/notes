---
definition: "The explanation or meaning of the term."
---

# Term
