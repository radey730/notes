[[Control Types]]
[[Non- repudiation]]
[[AAA Security Architecture ]] 

10/7/24
	Second score after some study/notes: 18/25 (81%)
	Wrong Answers: 
	The term "Non-repudiation" describes the inability to deny responsibility for performing a specific action. In the context of data security, non-repudiation ensures data confidentiality, provides proof of data integrity, and proof of data origin. - 
		FALSE
	Which of the terms listed below can be used to describe the basic principles of information security?
		AAA and CIA (missed CIA)
	Which of the following terms fall into the category of directive security controls?
		IRP and AUP (missed both)
	Which of the answers listed below refer(s) to compensating security control(s)?
		Backup power, MFA, Application Sandboxing, Network Segmentation 
		(missed MFA)
	Which of the answers listed below refer(s) to detective security control(s)?
		Log Monitoring, Security Audits, CCTV, IDS, Vulnerability Scanning 
		(missed Security Audit)
	Which of the following examples do not fall into the category of physical security controls?
		I DIDNT READ THE "DO NOT" AND SELECTED ALL THE PHYSICAL SECURITY CONTROLS
	Which of the following examples fall into the category of operational security controls? 
		-    Risk assessments ( WRONG)
			- Falls under managerial security controls, as it involves evaluating risks rather than day-to-day operational activities.
		-    Configuration management ( CORRECT /M)
			- Ensures system settings and configurations align with security policies.
		-    System backups ( CORRECT /M)
			- Regular backups help protect data from loss or corruption, a key part of operational security.
		-    Authentication protocols ( WRONG)
			- Typically categorized as technical controls because they focus on the specific technical mechanisms for access control.
		-    Patch management ( CORRECT)
			- Involves applying updates and patches to software to protect systems from vulnerabilities.
		Explanation
				Operational security controls are actions or processes implemented to maintain and manage security on an ongoing basis. These examples involve the day-to-day operations that help secure systems, maintain configurations, and ensure data availability.

3rd Score: 

