[[Authentication]]- which is verification of identity of person or process)
	[[Authorization]]- the process of granting or denying access to resources
	[[Accounting]]-  the process of tracking accessed services as well as the amount of consumed resources
Which of the following solutions provide(s) the AAA functionality?
	 - TACACS, RADIUS
Common methods of device authentication used within the AAA framework
	 - Digital certificate
	 - IP Addresses
	 - Mac Addresses 
Common methods of people authentication used within the AAA framework
		 - Username password
		 - biometric
		 - MFA