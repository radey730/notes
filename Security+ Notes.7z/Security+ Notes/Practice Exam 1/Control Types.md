
### Categories- **How** the control is applied
[[Technical security controls]] I.E Logical controls
	- implemented through technology
	- executed by computer systems NOT PEOPLE
	- [[Firewalls]], [[antivirus]], [[IDS]]s, encryption

[[Managerial Security Controls]] - I.E  Administrative Controls
	 - Controls that address security design and implementation
	 - security *policies*, standard operating procedures

[[Operational Security Controls]] 
	Day-to-day basis to manage security
		Operational security controls are actions or processes implemented to maintain and manage security on an ongoing basis. These examples involve the day-to-day operations that help secure systems, maintain configurations, and ensure data availability.
	awareness programs, patch management

Physical Controls
	Security Guards
	Fences and gates
	surveillance cameras





### Control Types- **Purpose** of the control
Preventative
 - encryption
 - 
Deterrent Security Controls
	- Warning signs, Lighting, Fences/bollard 
Detective
	Controls come into play when *preventative and directive measures fail*
	identifying incidents as they occur or after they happen
	IDS, security audits
Corrective 
	Fix issues after detection, restoring systems to proper state
	 - Backup data copy, software update/patches to fix vulnerability, 
	 - executing [[DRP]]s, Developing [[IRP]]s
Compensating
	alternative controls when primary controls are unavailable
		(example: restricting access to certain systems if encryption isn't available)
	 - Backup Power
	 - MFA
	 - Application Sandboxing
	 - Network segmentation

Directive sec control
	Ensure certain actions are followed like policies and guidelines 
 - Log Monitoring, Security Audits, [[IDS]]
 - Policies and procedures (same as [[Managerial Security Controls]]?)
 - IRP, AUP



