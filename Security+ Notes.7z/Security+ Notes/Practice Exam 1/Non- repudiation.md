Definition
Key Aspects of non-repudiation
	Digital Signatures 
	Audit logs
	Examples
		in Email comms, digital signatures ensure that the sender cannot deny sending the email
		In financial transactions, non-repudiation ensures that a user cant later dispute a transaction that was authorized by their credentials 