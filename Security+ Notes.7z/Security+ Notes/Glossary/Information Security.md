---
definition: Protecting data and information from unauthorized access, modification, disruption, disclosure, and destruction
tags:
  - vocab
---

