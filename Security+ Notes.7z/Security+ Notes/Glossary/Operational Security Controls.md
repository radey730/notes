---
definition: Controls implemented by PEOPLE ; I.E Physical
tags:
  - vocab
---
---
Examples
- **security guard**
- **Fencing**: Barriers around a facility to prevent unauthorized entry.
- **Surveillance cameras (CCTV)**: Monitoring activity around sensitive areas.
- **Locks and access control systems**: Limiting access to sensitive areas with physical locks or badge/keycard systems.
- **Biometrics**: Physical access control using unique biological traits (e.g., fingerprints, retina scans).
- **Mantraps**: Small rooms with two locking doors, used to secure access to sensitive areas by limiting the number of people who can enter.
- **Alarms and motion detectors**: Detect unauthorized access attempts.