---
definition: consist of the hardware and software components that protect a system against cyberattack. ; I.E Logical
tags:
  - vocab
---
---
Examples:  
- Firewalls
- intrusion detection systems (IDS)
- encryption
- identification and authentication mechanisms
- **IDPS**: IDS detects threats; IPS prevents them.
- **Antivirus/Antimalware**: Detect and remove malicious software.
- **VPNs**: Encrypt communication over networks (site-to-site, remote-access).
- **DLP**: Prevent unauthorized data transfers.
- **SIEM**: Centralized log monitoring for real-time threat detection.
- **Patch Management**: Keep systems up to date to address vulnerabilities.
- **Application Whitelisting**: Only allow pre-approved apps to run.
- **EDR**: Real-time endpoint monitoring and response.