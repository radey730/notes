---
definition: a control that focuses on the design of the security or the policy implementation I.E Administrative controls
tags:
  - vocab
aliases:
  - Administrative controls
---
- I.E Administrative controls 
- focused on reducing risk of security incidents 
- documented in written **policies**

--- 
Examples
- Organizational security policy
- security awareness training
- risk assessments 
- employee training