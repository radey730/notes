A hierarchical system for the creation, management, storage, distribution, and revocation of digital certificates 
#vocab