Process that asses the potential impact of disruptive incident or disasters on critical business function

#vocab 