---
definition: |-
  *Confidentiality* - Ensures information is accessible only to authorized personnel (e.g., encryption)       
  *Integrity* -   Ensures data remains accurate and unaltered (e.g., checksums)       
  *Availability*  -   Ensures information and resources are accessible when needed (e.g., redundancy measures)
tags:
  - vocab
---

## Definition
The CIA Triad is a model designed to guide policies for information security within an organization. It is composed of three principles: Confidentiality, Integrity, and Availability.

#vocab 