Intrusion Detection System
#vocab 
	What is the difference between firewall and IDS? 
		A firewall controls access to a network by blocking or permitting traffic based on security rules, while an IDS monitors and analyzes network traffic for suspicious activities to detect potential threats.