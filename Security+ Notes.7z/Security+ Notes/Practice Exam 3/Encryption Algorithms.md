Symmetric Encryption
	**single** shared key for both encryption + decryption. 
	**Fast and efficient** and use for **large amount of data**
* DES (**legacy**) - Data Encryption Standard
	* small key size makes it vulnerable to attack to its outdated now
* AES (**current**) - supports 128, 192, and 256-bit key
	* Advanced Encryption Standard 
	* CCMP (protocol) applies AES (algorithm) to secure data in WPA2 networks
* RC4 - (now **insecure**) Simple and fast ; once was used in SSL and TLS protocols 
	* stream cypher that **encrypts data by operating on it one byte at a time** 
		* vulnerable (key reuse leaks)
* Symmetric Ciphers
	* AES + DES
	* IDEA
	* RC4


[[Asymmetric Encryption]]
* RSA - common for digital signatures, SSL/TLS, and key exchanges
	* relies on the difficulty of factoring large integers 
	* security increases with key size (eg. 2048-bit)
* ECC - ideal for mobile security, digital signatures, SSL/TLS
	* ^ because of its smaller key size.
		* 256 bit ECC vs 3072 bit RSA

Asymmetric Ciphers
* DHE
* ECC
* RSA