* IPSEC
	* Suite of protocols that provide encryption, authentication, and data integrity for network traffic
		Network layer (layer 3) 
			making it ideal for IP-based communication like VPN 
	* AH (Authentication Header)
		* Different from ESP because it adds Authentication and Integrity by adding extra
		* Authentication: 
			* authenticates entire packet including IP header 
		* Integrity: 
			* Protects packet from modification during transmission
	* ESP (Encapsulating Security Payload)
		* Confidentiality 
			* Encrypts data payload ensuring its private during transmission
		* Authentication
			* Authenticate data payload verifying sender and ensuring integrity
		* Integrity
			* Protects data from alternation during transit
	* IKE (Internet Key Exchange)
		* Handles key management and negotiation between two endpoints
		* establishes shared keys for encryption and authentication
		* establishes SA (Security Association) 
			* SA's define how IPSEC connection will secured


| Component | Provides                                       |
| --------- | ---------------------------------------------- |
| AH        | Authentication Integrity (no encyrption)       |
| ESP       | Confidentiality, Authentication, and Integrity |
| IKE       | Key Management, Security Policy negotiation    |
| SA        | Defines parameters for Secure Communication    |
| DH        | Secure Key Exchange                            |
