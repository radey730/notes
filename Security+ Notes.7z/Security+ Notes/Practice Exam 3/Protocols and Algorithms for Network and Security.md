[[Remote Access Protocols | Protocols for Remote Access]]
- **RDP** #application-layer
- **SSH** #application-layer
- **Telnet** #application-layer

Protocols for Secure Communication
	[[Network Security Protocols]]
		IPsec
			ESP, IKE, AH
	 SSL and TLS ; VPN ; DNSSEC ; DH
	File transfer Protocol
		SFTP ; FTP

[[Encryption Algorithms]]
	Symmetric Encryption
		DES ; AES ; RC4
	Asymmetric encryption
		RSA ; ECC

Hashing Algorithms
	MD5(insecure) ; SHA-1(insecure) ; SHA-2 ; Blowfish and Twofish ; HMAC

[[Authentication and Key Exchange]]
	Authentication methods: 
		PSK, EAP ; RADIUS ; Kerberos
	Key Exchange Methods
		DHE(part of IKE), ECDHE, PFS
	Key Management
		KEK

WiFi Security
	WPA, WPA2 (CCMP), WEP(TKIP)
		PSK

IPSEC Components 
	ESP