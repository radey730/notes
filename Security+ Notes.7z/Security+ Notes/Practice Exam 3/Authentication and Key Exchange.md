Authentication methods: 
	PSK, EAP ; RADIUS ; Kerberos


Key Exchange Methods
		DHE, ECDHE, PFS



Key Management
		KEK