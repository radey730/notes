## 601Questions
##### Which of the answers listed below refers to a suite of protocols and technologies providing encryption, authentication, and data integrity for network traffic? 
##### IPSEC

##### SFTP is an extension of the FTP protocol that adds support for SSL/TLS encryption. True or False?
##### false 

##### Network protocol that enables secure file transfer over SSH? 
##### SFTP

##### Which part of IPsec provides authentication, integrity, and confidentiality?
##### ESP (?)

##### Secure, real-time delivery of audio and video over an IP Network- 

##### Which of the following answers refer(s) to deprecated/insecure encryption protocols and cryptographic hash functions?
##### DES MD5 SHA-1 SSL RC4

##### Successor to SSL?
##### TLS

##### Examples of techniques used for encrypting information include symmetric encryption (also called public-key encryption) and asymmetric encryption (also called secret-key encryption, or session-key encryption).
##### false

##### In asymmetric encryption, any message encrypted with the use of a public key can only be decrypted by applying the same algorithm and a matching private key (and vice versa). 
##### true

##### The term "KEK" refers to a type of cryptographic key often used in key management systems to add an additional layer of security when encrypting and decrypting other cryptographic keys.
##### TRUE

##### Which of the answers listed below refers to a shared secret authentication method used in WPA, WPA2, and EAP?
##### PSK

##### Which of the following answers refers to a protocol used to set up secure connections and exchange of cryptographic keys in IPsec VPNs?
##### IKE

##### Which of the answers listed below refers to a key exchange protocol that generates temporary keys for each session, providing forward secrecy to protect past and future communications?
##### DHE

##### Which of the following answers refers to a cryptographic key exchange protocol that leverages ECC for enhanced security and efficiency?
##### ECDHE

##### Which of the following answers refers to a public-key cryptosystem used for digital signatures, secure key exchange, and encryption?
##### RSA

##### Which cryptographic solution would be best suited for low-power devices, such as IoT devices, embedded systems, and mobile devices?
##### ECC

##### Which of the cryptographic algorithms listed below is the least vulnerable to attacks?
AES



## 701 Questions
	