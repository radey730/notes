- **RDP (Remote Desktop Protocol):** A protocol developed by Microsoft for remote access to a desktop environment over a network connection.  
	- graphical interface
- **SSH (Secure Shell):** A protocol used for secure remote login and other secure network services over an unsecured network.
	- Uses command-line access 
- **Telnet:** An older, insecure protocol used for remote command-line login, superseded by SSH.

